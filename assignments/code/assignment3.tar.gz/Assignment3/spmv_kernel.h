#ifndef SPMV_KERNEL_H
#define SPMV_KERNEL_H

void spmv(int m, int n, float *A, float *B, float *C);

#endif
